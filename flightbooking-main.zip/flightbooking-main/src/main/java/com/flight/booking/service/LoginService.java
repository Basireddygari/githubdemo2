/**
 * 
 */
package com.flight.booking.service;

import org.springframework.security.core.userdetails.UserDetailsService;

/**
 * @author navin
 *
 */
public interface LoginService extends UserDetailsService{

}
